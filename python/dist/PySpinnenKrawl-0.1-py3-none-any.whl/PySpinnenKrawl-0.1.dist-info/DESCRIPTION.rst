
This is an experimental project

https://packaging.python.org/
https://devcenter.heroku.com/articles/python-pip
https://packaging.python.org/tutorials/distributing-packages


